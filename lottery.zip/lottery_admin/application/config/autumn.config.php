<?php
$config['seeting'] = array(
	'base_url' => 'http://127.168.0.1/lottery/lottery_admin/',
	'api_url' => 'http://api..com/',

	'admin_view' => 'admin',
	'home_view' => 'home'
);

$config['actype'] = array('投注');

