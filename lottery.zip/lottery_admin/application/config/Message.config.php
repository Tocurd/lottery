<?php
$config['message'] = array(
	'Admin_User_Not_Login' => '对不起，您还未登陆无法进行操作'
);