<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<base href="{base_url}">
	<link rel="stylesheet" href="./assets/css/admin/style.css">
	<link rel="stylesheet" href="./assets/bin/font-awesome/font-awesome.min.css">