<div class="top-header">
	<div class="item">
		<i class="fa fa-cog"></i>
		<span>系统设置</span>
	</div>
	<div class="item">
		<i class="fa fa-list"></i>
		<span>投注管理</span>
	</div>
	<div class="item">
		<i class="fa fa-user-o"></i>
		<span>用户列表</span>
	</div>
	<div class="item">
		<i class="fa fa-plus"></i>
		<span>添加用户</span>
	</div>

	<div class="item">
		<i class="fa fa-file-text-o"></i>
		<span>充值管理</span>
	</div>

	<div class="item">
		<i class="fa fa-list"></i>
		<span>提现管理</span>
	</div>



	<div class="item" style="float: right;">
		<i class="fa fa-bell-o"></i>
		<span>新消息</span>
		<div class="news"></div>
		<div class="list-message">
			<ul>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
			</ul>
		</div>
	</div>
	<div class="item" style="float: right;">
		<i class="fa fa-envelope-o"></i>
		<span>内部邮件</span>
		<div class="news"></div>
	</div>
</div>