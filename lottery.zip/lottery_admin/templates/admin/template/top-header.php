<div class="top-header">
	<div class="item">
		<i class="fa fa-bell-o"></i>
		<span>新消息</span>
		<div class="news"></div>
		<div class="list-message">
			<ul>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
				<li><a href="">您有最新的消息</a><span class="time">4-07</span></li>
			</ul>
		</div>
	</div>
	<div class="item">
		<i class="fa fa-envelope-o"></i>
		<span>内部邮件</span>
		<div class="news"></div>
	</div>
</div>