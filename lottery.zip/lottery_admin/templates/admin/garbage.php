	<style type="text/css">
		.fezocms{padding:7px 27px;}
	</style>
</head>
<body>
	<?php $this->load->view($admin_view . '/template/menu.php' , array('song_active' => 1))?>
	<?php $this->load->view($admin_view . '/template/top-header.php')?>

	<div class="warpper">
		<div class="box">
			<h1>垃圾扫描</h1>
			<button class="btn fezocms"><i class="fa fa-search"></i>开始扫描</button>
		</div>
		<table class="table-list">
			<tr>
				<th><input type="checkbox"></th>
				<th>垃圾文件地址</th>
				<th>垃圾类型</th>
				<th>创建时间</th>
				<th>是否建议删除</th>
			</tr>
			<tr>
				<td><input type="checkbox"></td>
				<td>D:\Adobe Photoshop CS6\Adobe Photoshop CS6\OBLRes\zh_TW</td>
				<td>垃圾文件</td>
				<td>2017年4月24日11:46:06</td>
				<td>是</td>
			</tr>
			<tr>
				<td><input type="checkbox"></td>
				<td>D:\Adobe Photoshop CS6\Adobe Photoshop CS6\OBLRes\zh_TW</td>
				<td>垃圾文件</td>
				<td>2017年4月24日11:46:06</td>
				<td>是</td>
			</tr>
			<tr>
				<td><input type="checkbox"></td>
				<td>D:\Adobe Photoshop CS6\Adobe Photoshop CS6\OBLRes\zh_TW</td>
				<td>垃圾文件</td>
				<td>2017年4月24日11:46:06</td>
				<td>是</td>
			</tr>
			<tr>
				<td><input type="checkbox"></td>
				<td>D:\Adobe Photoshop CS6\Adobe Photoshop CS6\OBLRes\zh_TW</td>
				<td>垃圾文件</td>
				<td>2017年4月24日11:46:06</td>
				<td>是</td>
			</tr>
			<tr>
				<td><input type="checkbox"></td>
				<td>D:\Adobe Photoshop CS6\Adobe Photoshop CS6\OBLRes\zh_TW</td>
				<td>垃圾文件</td>
				<td>2017年4月24日11:46:06</td>
				<td>是</td>
			</tr>
			<tr>
				<td><input type="checkbox"></td>
				<td>D:\Adobe Photoshop CS6\Adobe Photoshop CS6\OBLRes\zh_TW</td>
				<td>垃圾文件</td>
				<td>2017年4月24日11:46:06</td>
				<td>是</td>
			</tr>
			<tr>
				<td><input type="checkbox"></td>
				<td>D:\Adobe Photoshop CS6\Adobe Photoshop CS6\OBLRes\zh_TW</td>
				<td>垃圾文件</td>
				<td>2017年4月24日11:46:06</td>
				<td>是</td>
			</tr>
			<tr>
				<td><input type="checkbox"></td>
				<td>D:\Adobe Photoshop CS6\Adobe Photoshop CS6\OBLRes\zh_TW</td>
				<td>垃圾文件</td>
				<td>2017年4月24日11:46:06</td>
				<td>是</td>
			</tr>
			<tr>
				<td><input type="checkbox"></td>
				<td>D:\Adobe Photoshop CS6\Adobe Photoshop CS6\OBLRes\zh_TW</td>
				<td>垃圾文件</td>
				<td>2017年4月24日11:46:06</td>
				<td>是</td>
			</tr>
			<tr>
				<td><input type="checkbox"></td>
				<td>D:\Adobe Photoshop CS6\Adobe Photoshop CS6\OBLRes\zh_TW</td>
				<td>垃圾文件</td>
				<td>2017年4月24日11:46:06</td>
				<td>是</td>
			</tr>
		</table>
	</div>
	
	<?php $this->load->view($admin_view . '/template/footer.php')?>
</body>
</html>